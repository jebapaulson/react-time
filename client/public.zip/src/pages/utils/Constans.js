const constants = {
  segments: "Save Segments",
  save: "Save",
  cancel: "Cancel",
  addSchema: "Add schema to segment",
  newSchema: "+ Add new schema",
};
export default constants;
