// const express = require("express");
// const axios = require("axios");
// const cors = require("cors");
// const app = express();

// app.use(cors());
// app.use(express.json());

// app.post("/proxy", async (req, res) => {
//   try {
//     const response = await axios.post(
//       "https://webhook.site/5752c62e-e518-47a9-a79b-3fa24100620e",
//       req.body
//     );
//     res.json(response.data);
//   } catch (error) {
//     res.status(500).send(error.toString());
//   }
// });

// app.listen(3000, () => console.log("Proxy server listening on port 5000"));
